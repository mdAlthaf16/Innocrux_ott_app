package com.task.innocrux.features.moviedetail.domain.model

data class MovieDetailRequest(
    val movieId: Int
)